package com.cg.student.service;

import java.util.ArrayList;

import com.cg.student.bean.StudentBean;
import com.cg.student.dao.IStudentDao;
import com.cg.student.dao.StudentDaoImpl;

public class StudentServiceImpl implements IStudentService{

	IStudentDao dao = new StudentDaoImpl();
	@Override
	public ArrayList<StudentBean> getDetails() {
	
		return dao.getDetails();
	}
	@Override
	public int addStudentDetails(StudentBean bean) {
		
		return dao.addStudentDetails(bean);
	}

}
