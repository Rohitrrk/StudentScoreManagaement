package com.cg.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.student.bean.StudentBean;
import com.cg.student.dbutil.Dbutil;

public class StudentDaoImpl implements IStudentDao{

	Connection conn= null;
	@Override
	public ArrayList<StudentBean> getDetails() {
		
		ArrayList<StudentBean> list= new ArrayList<StudentBean>();
		int res=0;
		try{
			
			conn = Dbutil.getConnection();
			String sql = "Select * from Student_Score";
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while(rs.next())
			{
				String studName = rs.getString(2);
				int Age = rs.getInt(3);
				String country = rs.getString(4);
				String gender= rs.getString(5);
				int noOfSub = rs.getInt(6);
				int attempts = rs.getInt(7);
				int total = rs.getInt(8);
				list.add(new StudentBean(studName,Age,country,gender,noOfSub,attempts,total));
			}
			for( StudentBean o:list)
			{
				System.out.println(o);
			}
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return list;
	}
	
	
	@Override
	public int addStudentDetails(StudentBean bean) {
		
		int row=0;
        try{
			
			conn = Dbutil.getConnection();
			PreparedStatement ps=conn.prepareStatement("INSERT INTO Student_Score VALUES(stud_id.nextval,?,?,?,?,?,?,?)");
			
			ps.setString(1, bean.getStudentname());
			ps.setInt(2, bean.getAge());
			ps.setString(3, bean.getCountry());
			ps.setString(4, bean.getGender());
			ps.setInt(5, bean.getNoOfSub());
			ps.setInt(6, bean.getAttempts());
			ps.setInt(7, bean.getTotal());
							
			row = ps.executeUpdate();
			
        }
        catch(SQLException e)
        {
        	System.out.println("SQL Error ah re baba");
        }
		
		return row;
	}
	

}
