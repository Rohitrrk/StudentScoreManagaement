package com.cg.student.bean;

public class StudentBean {
	private String studentname;
	private int age;
	private String country;
	private String gender;
	private int noOfSub;
	private int attempts; 
	private int total;
	
	public StudentBean()
	{
		
	}
	
	public StudentBean(String studentname, int age, String country,
			String gender, int noOfSub, int attempts, int total) {
		super();
		this.studentname = studentname;
		this.age = age;
		this.country = country;
		this.gender = gender;
		this.noOfSub = noOfSub;
		this.attempts = attempts;
		this.total = total;
	}
	
	
	@Override
	public String toString() {
		return "StudentBean [studentid=" + studentid + ", studentname="
				+ studentname + ", age=" + age + ", country=" + country
				+ ", gender=" + gender + ", noOfSub=" + noOfSub + ", attempts="
				+ attempts + ", total=" + total + "]";
	}
	private int studentid;
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getNoOfSub() {
		return noOfSub;
	}
	public void setNoOfSub(int noOfSub) {
		this.noOfSub = noOfSub;
	}
	public int getAttempts() {
		return attempts;
	}
	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	
	

	
	

	
	
	
}
