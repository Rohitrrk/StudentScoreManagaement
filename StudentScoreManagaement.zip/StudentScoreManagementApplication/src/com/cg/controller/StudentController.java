package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import javax.servlet.http.HttpSession;

import com.cg.student.bean.StudentBean;
import com.cg.student.service.IStudentService;
import com.cg.student.service.StudentServiceImpl;

@WebServlet("*.obj")
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	IStudentService service = new StudentServiceImpl();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String target = null;;
		String path = request.getServletPath();
		StudentBean bean = new 	StudentBean();
		switch(path)
		{
		case "/retrieveDetails.obj":
		
			ArrayList<StudentBean> list= new ArrayList<StudentBean>();
			list = service.getDetails();
			for(StudentBean o:list)
			{
				System.out.println("In Controler"+o);
			}
			
			HttpSession session = request.getSession(true);
			session.setAttribute("StudData", list);
			
			target="StudentScore.jsp";
			
			break;
			
		case "/newStudent.obj":
			
			target = "NewStudent.jsp";
			
			break;
		
		case "/addStudentDetails.obj" :
			
			String studname = request.getParameter("studName");
			
			String age = request.getParameter("age");
			int studAge=Integer.parseInt(age);
			
			String state = request.getParameter("state");
			String gender= request.getParameter("gen");
			
			String noOfSub = request.getParameter("noOfSub");
			int sub =Integer.parseInt(noOfSub);
			
			String attempts = request.getParameter("noAtmpt");
			int atmpt=Integer.parseInt(attempts);
			
			String total= request.getParameter("total");
			int totalScore=Integer.parseInt(total);
			
			bean.setStudentname(studname);
			bean.setAge(studAge);
			bean.setCountry(state);
			bean.setGender(gender);
			bean.setNoOfSub(sub);
			bean.setAttempts(atmpt);
			bean.setTotal(totalScore);
			
			
			int res = service.addStudentDetails(bean);
			
			
			if(res == 1)
			{
				
				 target = "InsertSuccess.jsp";
			}
			else
			{
				target = "Error.jsp";
			}
			break;
		}
		
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}


}
